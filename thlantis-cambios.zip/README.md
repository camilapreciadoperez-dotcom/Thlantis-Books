# Thlantis Books

Plataforma cultural sobre literatura: artículos, audiolibros, biografías de autores y videos.
Proyecto productivo del tecnólogo en Multimedia Web (SENA), creado por Camila Preciado.

Sitio: https://camilapreciadoperez-dotcom.github.io/Thlantis-Books/

## Tecnologías
HTML5, CSS3, JavaScript, íconos Lucide y GitHub Pages.

## Estructura
- `index.html` y `style.css`: portada
- `AUTORES/`, `BLOG/`, `AUDIOLIBROS/`, `VIDEOS/`, `CONTACTO/`: secciones
- `css/`: estilos compartidos
- `js/`: menú móvil y formularios
- `GALERÍA/`: imágenes

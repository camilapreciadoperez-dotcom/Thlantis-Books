// Menú móvil compartido por todas las páginas.
(function () {
    if (window.lucide) lucide.createIcons();

    const boton = document.getElementById('menu-toggle');
    if (!boton) return;
    const menu = document.getElementById(boton.getAttribute('aria-controls'));

    function cambiar(abrir) {
        menu.classList.toggle('active', abrir);
        boton.setAttribute('aria-expanded', abrir);
        boton.setAttribute('aria-label', abrir ? 'Cerrar menú' : 'Abrir menú');
    }
    boton.addEventListener('click', () => cambiar(!menu.classList.contains('active')));
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && menu.classList.contains('active')) {
            cambiar(false);
            boton.focus();
        }
    });
})();

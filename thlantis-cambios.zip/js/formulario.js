// Un sitio estático no puede enviar correos: se abre la aplicación de correo del visitante.
document.querySelectorAll('form[data-correo]').forEach((form) => {
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const cuerpo = [...new FormData(form)]
            .map(([campo, valor]) => `${campo}: ${valor}`)
            .join('\n');
        location.href = `mailto:${form.dataset.correo}?subject=${encodeURIComponent('Mensaje desde Thlantis Books')}&body=${encodeURIComponent(cuerpo)}`;
    });
});
